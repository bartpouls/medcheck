---
name: gauntlet-loop
description: "Gauntlet Loop: laat werk bouwen, hard beoordelen door een aparte 'blinde' criticus, en herhalen tot het een echte, benoemde lat haalt. Werkt in twee standen: (1) schrijf één plakklare prompt voor een verse sessie, (2) draai de loop zelf, met een live voortgangsdashboard (HTML). Werkt met subagents (Claude Code) én zonder (Mistral Vibe, Claude Desktop chat) via rolscheiding en overdrachtsbestanden. Trigger op 'gauntlet loop', 'gauntlet this', 'loop until it beats X', 'bouwer en criticus', 'blinde A/B', 'blijf itereren tot het goed is', 'maak dit wereldklasse', 'voortgangsdashboard'."
user-invocable: true
---

# Gauntlet Loop

Methode van Matt Shumer (somethingbig.ai/gauntlet-loop). Basis: robonuggets/gauntlet-loop (prompt-schrijver, regels voor de lat). Uitbreidingen: trilwu/gauntlet-loop-skills (criticus-ontwerp, stopregels, workbench, smoothing pass). Dit is een eigen, gecombineerde bewerking; alles is tekstinstructie en niet aan één tool gebonden.

Kern: **bouwen → blind beoordelen tegen een echte lat → herstellen → herhalen.** De bouwer beoordeelt nooit zijn eigen werk.

## Stap 0 — kies de stand

- Wil de gebruiker alleen een prompt (of is dit niet de plek om te grinden)? → **Stand A: prompt schrijven.**
- Wil de gebruiker dat je het nu uitvoert ("run it", "draai maar")? → **Stand B: loop draaien.**
- Onduidelijk? Doe Stand A en sluit af met één vlakke regel: "Ik kan dit hier draaien."

## De lat (het hele trucje)

Elke lat moet vier toetsen doorstaan:
- **Benoemd.** Een specifiek ding, geen categorie. ("Het NHG-standpunt over X", niet "goede richtlijnen".)
- **Ophaalbaar.** De criticus kan het echt openen (URL, bestand, repo, tekst, testset). Kan het niet, dan verzint de agent de vergelijking.
- **Vergelijkbaar.** Naast elkaar leggen en kiezen moet kunnen.
- **Haalbaar en eindig.** Er bestaat een resultaat dat deze lat kan halen, met de middelen van deze sessie, en een criticus kan in eindige tijd PASS zeggen. Twee veelvoorkomende fouten:
  - *Onhaalbare referentie* ("zelfde familie als 16 met de hand getekende prints" met een procedurele tekenaar). Splits dan: **poortcriteria** (moeten gehaald, bepalen PASS) en **streefcriteria** (worden alleen gerapporteerd onder "nog onder de lat", bepalen nooit FAIL).
  - *Negatieve bewijsplicht* ("bewijs dat er nergens iets hardgecodeerd is"). Dat kan nooit af. Maak er een meetbare drempel van vóór de start ("mutantscore ≥ X", "scan met deze lijst van omzeilingen slaagt") of laat het weg.

Noemt de gebruiker geen lat: bied **2–3 kandidaat-latten** (één regel elk, de hardste die haalbaar is) en **stop en wacht op de keuze**. Noem ook de meetbare helft als die er is (aantal fouten, woordenaantal, slagingspercentage). Smaak plus een getal verslaat smaak alleen.

Voorbeelden voor onderwijswerk: antwoordmodel → een bestaand, goedgekeurd antwoordmodel plus de beoordelingsregels; tentamenvraag → de toetsmatrijs en eerder gevalideerde vragen; farmacologische inhoud → Farmacotherapeutisch Kompas of NHG als controleerbare bron; leerroute → de leeruitkomsten waarop ze moet aligneren.

## Het type lat (bepaalt rondes, stopregel en criticus)

Kies per stuk één type en schrijf het in het dashboard bij de lat. Twijfel je, kies dan het zachtste type; liever te weinig rondes en een correctie van de gebruiker dan te veel rondes.

| Type | Voorbeeld | Rondes en stopregel |
|---|---|---|
| **Inhoud tegen bron** | Klopt elke kaart/tekst/getal letterlijk met de bron? | Volle loop. Stop zodra de blinde check 0 afwijkingen geeft, ook als het minimum niet gehaald is. Minimum 2 rondes alleen als ronde 1 PASS gaf zonder dat de criticus ook maar één punt vond (verdacht mild). |
| **Bewijs of testdekking** | "Test X bewijst dat Y niet kan." | Maximaal 2 rondes, tenzij de lat een vooraf afgesproken drempel heeft. Gedrag correct maar bewijs onvolledig = melden onder de lat, niet doorbouwen. |
| **Smaak of beleving** | Afbeelding, vormgeving, gevoel van een UI | Eén bouwronde, één verse controle op de harde poortcriteria, daarna de correctielijst van de gebruiker. De gebruiker is hier de goedkoopste en betrouwbaarste lat. Meer blinde rondes alleen als de gebruiker erom vraagt. |

## Stand A — prompt schrijven (±150–200 woorden)

Eén blok, plakklaar, geen kopjes erin, geen uitleg erna. Pas de woorden telkens aan, vul de haken, houd de laatste regel.

```
Maak [DOEL].

De lat is [LAT], type [inhoud tegen bron | bewijs | smaak]. Haal het echte ding eerst op en vergelijk er rechtstreeks mee, niet met een beschrijving ervan. Splits de lat in poortcriteria (moeten gehaald, bepalen PASS) en streefcriteria (alleen rapporteren). Neem niets op wat niet haalbaar of niet in eindige tijd te beoordelen is.

Splits dit in de kleinste stukken die los te verbeteren en te beoordelen zijn. Laat per stuk een bouwer en een aparte, harde criticus met verse context werken. De criticus bekijkt het echte resultaat, legt het blind (labels weg) naast de lat, zegt welke beter is, en noemt de grootste resterende kloof. Daarna terug naar de bouwer.

De criticus is streng. Lof is nutteloos. Standaard is het oordeel FAIL tot bewijs het tegendeel laat zien.

Vergelijk elke ronde met de beste versie tot nu toe en bouw verder vanaf die beste, niet vanaf de laatste. Stop per stuk zodra de criticus ons blind kiest en de poortcriteria gehaald zijn; bij inhoud tegen bron zodra er 0 afwijkingen zijn, bij bewijs na maximaal 2 rondes, bij smaak na één bouwronde plus gerichte correcties. Stop ook bij een ronde die niet beter is dan de beste (smaak) of twee rondes zonder winst (overig), en meld dan wat nog onder de lat zit.

Houd een live voortgangsdashboard bij (gauntlet/progress.html + progress.js) zodat ik kan meekijken.

Draai bouwers en critici als parallelle subagents als je dat kunt; kun je dat niet, werk dan per rol in aparte stappen met overdrachtsbestanden en zeg eerlijk dat het geen echt blinde review is.
```

Regels voor het invullen: maak de lat concreet; noem een budget alleen als de gebruiker er een noemde; schrijf geen architectuur, bestandsindeling of stack voor (de agent beslist dat beter); geen "N rondes en klaar". De uitgang is winnen, de stopregel, of de gebruiker.

## Stand B — de loop draaien

Je bent de **LEAD**. Je bouwt zelf niets: wie bouwt is een bevooroordeelde rechter.

### Rollen (nooit dezelfde context delen)
- **LEAD**: zet lat en budget, kiest het type lat, splitst in los beoordeelbare stukken, stuurt FAILs terug, houdt het dashboard bij.
- **BOUWER**: maakt één stuk als echt artefact (geen plan, geen beschrijving). Mag niet PASS roepen en de lat niet aanpassen.
- **CRITICUS**: ziet alleen artefact en lat, nooit de redenering van de bouwer. Details: `references/critic-design.md`.

### Twee uitvoeringsniveaus — wees eerlijk over welke je draait

**Niveau 1 — echt blind (subagents beschikbaar, bv. Claude Code).** Start per stuk een verse bouwer-subagent en per ronde een **verse** criticus-subagent. Parallel voor stukken die geen staat delen; serieel voor stukken die dat wel doen.

**Niveau 2 — rolscheiding zonder subagents (bv. Vibe, Desktop-chat).** Je kunt geen tweede context starten, dus:
1. Schrijf het artefact weg als bestand (`gauntlet/artefacten/<stuk>_r<n>.md`).
2. Schrijf een **overdrachtsbestand** voor de criticus (`gauntlet/criticus_<stuk>_r<n>.md`) met alleen: de lat, het criterialijstje en een verwijzing naar het artefact. Geen toelichting van de bouwer.
3. Beoordeel in een aparte stap als criticus, bij voorkeur in een **nieuwe sessie** die alleen dat overdrachtsbestand leest. Stel dat voor bij belangrijk werk. Binnen één sessie: begin met "Ik beoordeel nu uitsluitend op basis van lat en artefact" en negeer je eigen eerdere redenering.
4. Label het resultaat in het dashboard als **"zelfreview"** (niet blind). Zeg nooit dat een blinde gauntlet gedraaid heeft als dat niet zo is.

### De loop
1. **Lat, type en budget vastleggen** (lat verbatim in het dashboard, met type en de splitsing in poort- en streefcriteria). Toets de lat eerst aan de vier toetsen; faalt hij op "haalbaar en eindig", herschrijf of splits hem vóór je bouwt. Budget: maximum aantal rondes, parallelle breedte, eventueel tokens of tijd. Het minimum aantal rondes volgt uit het type lat (zie tabel), er is geen vast standaardminimum.
2. **Splitsen** in de kleinste stukken die los te bouwen en te beoordelen zijn.
3. **Bouwen** (vers, per stuk). Vanaf ronde 2 bouwt de bouwer verder op de **beste versie tot nu toe**, niet automatisch op de laatste.
4. **Beoordelen**: de criticus bekijkt het échte artefact, beoordeelt **elk poortcriterium apart** met bewijs (citaat, telling, meting), probeert minstens twee manieren om het werk te weerleggen, en doet blinde A/B tegen de lat waar dat kan. Binair oordeel (welke is beter, A of B) in plaats van cijfers: cijfers kruipen elke ronde omhoog. Streefcriteria worden gemeld, niet als FAIL geteld.
5. **Vergelijken met de beste**: leg de nieuwe ronde blind naast de beste versie tot nu toe. Is de nieuwe niet beter, dan blijft de beste staan, en telt dit als ronde zonder winst.
6. **Herstellen**: FAILs terug naar de bouwer mét de redenen van de criticus. Verzacht nooit een oordeel.
7. **Dashboard bijwerken na elke ronde**, niet pas aan het eind.
8. **Smoothing pass** (aanbevolen bij vijf of meer stukken): één verse agent bekijkt het samengestelde geheel op consistentie (terminologie, toon, opmaak, naden tussen stukken). Harmoniseren, niet herontwerpen; daarna de kritieke checks opnieuw.
9. **Rapport**: eindartefact (de beste versie), de lat verbatim, ronde-log, bewijs per stuk, wat nog onder de lat zit, en het verbruikte budget.

### Stoppen
Stop bij **een van**: elk stuk haalt de poortcriteria · de stopregel van het type lat (zie tabel) · budget op · de gebruiker zegt stop. Bij elk stuk geldt: een ronde die niet beter is dan de beste versie telt als ronde zonder winst; bij smaak is één zo'n ronde genoeg om te stoppen, bij andere typen twee op rij. Leg altijd vast wat nog onder de lat zit. Wordt het nog zichtbaar beter en is er budget, ga dan door, maar alleen als de blinde vergelijking dat laat zien; een gevoel van "bijna" is geen reden.

### Niet-onderhandelbare criteria
Bepaal vooraf welke criteria nooit worden ingeruild. Voor onderwijs en farmacologie bijvoorbeeld: een onjuiste farmacologische bewering of een niet-verifieerbare bron is altijd FAIL; een antwoordmodel dat niet aansluit bij de leeruitkomst is FAIL; getallen die niet kloppen met de bron zijn FAIL. De bouwer mag de lat of de testgevallen niet wijzigen; dat kan alleen LEAD en criticus samen.

## Het voortgangsdashboard

Bij de start van Stand B:
1. Maak de map `gauntlet/` in de werkmap.
2. Kopieer `assets/progress.html` (uit deze skill) naar `gauntlet/progress.html`.
3. Maak `gauntlet/progress.js` aan met de gegevens (formaat hieronder). **Na elke ronde herschrijf je dit bestand volledig.**
4. Zeg tegen de gebruiker: open `gauntlet/progress.html` in de browser. De pagina ververst zichzelf elke 10 seconden en werkt zonder server.

Formaat van `progress.js` (één toewijzing, geldige JavaScript). Zet het type lat en de splitsing poort/streef in het veld `bar`.

```js
window.GAUNTLET = {
  goal: "…", bar: "… (verbatim; type: …; poort: …; streef: …)", budget: "max 6 rondes",
  level: "blind",                      // "blind" (niveau 1) of "zelfreview" (niveau 2)
  status: "running",                   // "running" | "done" | "stopped"
  round: 3, maxRounds: 8,
  updated: "2026-10-11 14:05",
  units: [ { name: "…", round: 3, verdict: "PASS", // PASS | FAIL | PENDING
             evidence: "…", artifact: "gauntlet/artefacten/…" } ],
  log: [ { round: 1, unit: "…", verdict: "FAIL", note: "wat faalde → wat veranderde" } ],
  open: [ "vraag aan de gebruiker …" ],
  belowBar: [ "wat nog onder de lat zit …" ]
};
```

Houd de teksten kort en feitelijk; het dashboard is voor een mens die tussendoor kijkt. Zet vragen die de gebruiker moet beantwoorden in `open`.

## Wanneer NIET gebruiken
De loop kost vele malen meer tokens en tijd dan één pass. Sla hem over voor kleine, laagdrempelige klussen (snelle vraag, wegwerpscript, één zin aanpassen). Gebruik hem als kwaliteit er echt toe doet én je iets echts kunt noemen om tegen te meten. Bij puur smaakwerk is de volle loop bijna nooit nodig: een bouwronde, een controle op harde punten en de correctielijst van de gebruiker zijn goedkoper en beter.

## Bekende valkuilen
- **Vage lat**: de criticus verzint een vergelijking en keurt alles goed. Veruit de meest voorkomende fout.
- **Onhaalbare of oneindige lat**: de loop draait tot het maximum en levert niets meer op. Toets op "haalbaar en eindig" vóór de start.
- **Bouwer beoordeelt zichzelf**: rubberstempel.
- **Zachte criticus**: zeg "streng", geef een binaire taak, nieuwe criticus per ronde.
- **Verder bouwen vanaf de laatste ronde in plaats van de beste**: latere rondes kunnen slechter zijn dan een eerdere. Vergelijk altijd met de beste.
- **Vaste eindstop na N rondes zonder winst**: de uitgang is winnen, de stopregel van het type lat, of de gebruiker.
- **Overspecificeren**: elke extra instructie is een beslissing minder voor de agent.
- **Zelfreview als blind verkopen**: altijd eerlijk labelen.

## Referenties
- `references/critic-design.md` — hoe je een blinde criticus ontwerpt die echt inspecteert (afkomstig uit trilwu/gauntlet-loop-skills).
- `assets/progress.html` — zelfverversend dashboard (leest `progress.js`).
